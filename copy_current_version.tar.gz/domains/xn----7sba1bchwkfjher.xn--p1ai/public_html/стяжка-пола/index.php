<!DOCTYPE html>
<?php require_once __DIR__ . '/ABTest.php'; // Путь до файла ABTest.php ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="полусухая стяжка пола, полусухая стяжка цена, полусухая стяжка цена метр, полусухая стяжка москва, полусухая стяжка заказать, полусухая стяжка стоимость" />
    <meta name="description" content="Стяжка пола в Москве и области по немецкой технологии на любое напольное покрытие с гарантией 5 лет. ☎ +7(495)134-21-53 Бесплатная консультация и замер. 14 ведущих производителей материалов" />
    <meta name="viewport" content="width=device-width, user-scalable=1" />

    <title>Полусухая стяжка пола в Москве. Выгодная цена стяжки за метр</title>
	<link rel="icon" type="image/png" href="http://xn----7sba1bchwkfjher.xn--p1ai/favicon.png" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
	<link rel="canonical" href="/стяжка-пола/">
    <link rel="stylesheet" href="/стяжка-пола/css/normal.css">
    <link rel="stylesheet" href="/стяжка-пола/css/slicknav.min.css">
    <link rel="stylesheet" href="/стяжка-пола/css/style.css">
    <link rel="stylesheet" href="/стяжка-пола/js/jquery.arcticmodal-0.3.css">
    <link rel="stylesheet" href="/стяжка-пола/css/lightcase.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
    <script src="/стяжка-пола/js/jquery.slicknav.min.js"></script>
    <script src="/стяжка-пола/js/jquery.arcticmodal-0.3.min.js"></script>
    <script src="/стяжка-пола/js/lightcase.js"></script>
    <script src="/стяжка-пола/js/jquery.mask.js"></script>
    <script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
    <script src="/стяжка-пола/js/jquery.cookie.js"></script>
    <script src="/стяжка-пола/js/utm_multi_vid.js"></script>
    <script src="/стяжка-пола/js/script.js"></script>

</head>
<body>
<!-- Шапка -->
<div class="line-top">
    <div class="logo">
        <img src="img/logo.png">
    </div>
    <div class="link">
        <ul id="menu">
            <li><a href="#one" class="scrollto">Монтаж</a></li>
            <li><a href="#twoo" class="scrollto">Цены</a></li>
            <li><a href="#three" class="scrollto">Отзывы</a></li>
			<li><a href="#five" class="scrollto">Контакты</a></li>
        </ul>
    </div>
    <div class="phone-top">
        <a href="tel:+79684502828" class="phone roistat-phone" >+ 7 (968) 450 - 28 - 28</a>
        <a class="callback zvonok">Заказать обратный звонок</a>
    </div>
    <div class="clear"></div>
</div>

<div class="head-wrap">
    <div class="head block">
            <div class="utp-wrap">
                <div class="utp"><h1 class="multi">ПОЛУСУХАЯ СТЯЖКА ПОЛА ЗА 24 ЧАСА ПО НЕМЕЦКОЙ ТЕХНОЛОГИИ С ГАРАНТИЕЙ 5 ЛЕТ</h1></div>
               <!--  <div class="utp-line"></div>
                <div class="utp-decs"><p>Сэкономим до 10% за счет наших эксклюзивных скидок у 14 ведущих производителей материалов</p></div>
                <div class="button-wrap">
                    <div class="button zamer">Заказать бесплатный замер</div>
                </div> -->
                
            </div>
            <form  method="post" action="/amocrm/handler.php" class="form-left form newForm">
                <h3>ЗАКАЖИТЕ БЕСПЛАТНЫЙ ЗАМЕР СМЕТЫ СЕЙЧАС</h3>
                <p>И вы сэкономите до 10% за счет наших эксклюзивных скидок у 14 ведущих производителей материалов</p>
                <div class="formphone-wrap">
                    <input type="text" name="phone" placeholder="Введите Ваш телефон" value="" tabindex="3" class="formphone">
                </div>
                <div class="button send_mail" tabindex="4" onclick="yaCounter39798675.reachGoal('zakaz'); ga('send', 'event','kons','zakaz')">ЗАКАЗАТЬ ЗАМЕР СМЕТЫ</div>
                <p class="button-desc">* Перезвоним Вам за 23 секунды</p>
            </form>
            

			<a href="#four" class="scrollto"><div class="arrow"></div></a>
    </div>
</div>
<!-- Аргументы -->
<div class="arguments block" id="four">
    <h2>Аргументов много</h2>
    <div class="subtitle">
        <p>Но сравните сами по основным критериям насколько <br>полусухая стяжка пола по немецкой технологии отличается от <br>отбычной стяжки пола:</p>
    </div>
        <div class="table-wrap">
            <div class="table-l">
                <div class="column-1"></div>
                <div class="column-2"></div>
                <div class="column-3"></div>
                <div class="column-4"></div>
                <div class="column-5"></div>
                <div class="shadow"></div>
                <div class="border"></div>
                <div class="row row-1">
                    <p class="title col-1">Критерий <br>идеального пола</p>
                    <p class="title col-2">Обычная стяжка пола</p>
                    <p></p>
                    <p class="title col-3">Полусухая стяжка пола по немецким технологиям</p>
                    <p></p>
                </div>
                <div class="row row-2">
                    <p class="col-1">Качество покрытия</p>
                    <p class="col-2">Требует дополнительного выравнивания наливным полом</p>
                    <p></p>
                    <p class="col-3">Чистовая стяжка под любое напольное покрытие</p>
                </div>
                <div class="row row-3">
                    <p class="col-1">Перепад по высоте</p>
                    <p class="col-2">10 мм</p>
                    <p></p>
                    <p class="col-3">Всего 3 мм</p>
                    <p></p>
                </div>
                <div class="row row-4">
                    <p class="col-1">Угол наклона</p>
                    <p class="col-2">Только горизонтальная</p>
                    <p></p>
                    <p class="col-3">Возможно делать с любым углом наклона</p>
                    <p></p>
                </div>
                <div class="row row-5">
                    <p class="col-1">Появление трещин</p>
                    <p class="col-2">Возможно в процессе высыхания</p>
                    <p></p>
                    <p class="col-3">Трещины исключены</p>
                    <p></p>
                </div>
                <div class="row row-6">
                    <p class="col-1">Пешеходная нагрузка</p>
                    <p class="col-2">72 часа</p>
                    <p></p>
                    <p class="col-3">Всего 12 часов</p>
                    <p></p>
                </div>
                <div class="row row-7">
                    <p class="col-1">Отделочные работы</p>
                    <p class="col-2">28 дней</p>
                    <p></p>
                    <p class="col-3">8 дней</p>
                    <p></p>
                </div>
                <div class="row row-8">
                    <p class="col-1">Максимальная площадь <br>укладки в день 1 бригадой</p>
                    <p class="col-2">50 м2</p>
                    <p></p>
                    <p class="col-3">400 м2</p>
                    <p></p>
                </div>
                <div class="row row-9">
                    <p class="col-1">Прочность</p>
                    <p class="col-2">Высокая</p>
                    <p></p>
                    <p class="col-3">Высокая</p>
                    <p></p>
                </div>
                <div class="row row-10">
                    <p class="col-1">Риск протечек <br>во время монтажа</p>
                    <p class="col-2">Велик</p>
                    <p></p>
                    <p class="col-3">Протечки исключены</p>
                    <p></p>
                </div>
            <div class="clear"></div>
        </div>
    </div>
</div>
<!-- Фаворит -->
<div class="favorit block">
    <h2>Фаворит</h2>
    <div class="subtitle">
        <p>Фаворитом на сегодняшний день по всем <br>критериям идеального пола является полусухая <br>стяжка по немецкой технологии</p>
    </div>
    <div class="favorite-border">
        <div class="favorite-wrap">
            <div class="favorite-l">
                <div class="number">01</div>
                <h3>сочетание лучшего</h3>
                <p>Объединяет все достоинства сухой и мокрой стяжек, исключив их недостатки</p>
            </div>
            <div class="favorite-l">
                <div class="number">02</div>
                <h3>долгий срок службы</h3>
                <p>Обладает максимально длительным сроком службы</p>
            </div>
            <div class="favorite-l">
                <div class="number">03</div>
                <h3>технологичность</h3>
                <p>Выполняется по новейшей технологии, которая обеспечивает высокую скорость</p>
            </div>
            <div class="favorite-l">
                <div class="number">04</div>
                <h3>универсальность</h3>
                <p>Подходит для всех типов помещений и видов напольных покрытий</p>
            </div>
            <div class="clear"></div>
        </div>
    </div>
</div>
<!-- Форма сдлева -->
<div class="forma-left-bg">
    <div class="forma-left-wrap block">
        <form  method="post" action="/mail.php" class="form-left form">
            <h3>ЗАКАЖИТЕ БЕСПЛАТНЫЙ ЗАМЕР СМЕТЫ СЕЙЧАС</h3>
            <p>И вы сэкономите до 10% за счет наших эксклюзивных скидок у 14 ведущих производителей материалов</p>
            <div class="formphone-wrap">
                <input type="text" name="phone" placeholder="Введите Ваш телефон" value="" tabindex="3" class="formphone">
            </div>
            <div class="button send_mail" tabindex="4" onclick="yaCounter39798675.reachGoal('zakaz'); ga('send', 'event','kons','zakaz')">ЗАКАЗАТЬ ЗАМЕР СМЕТЫ</div>
            <p class="button-desc">* Перезвоним Вам за 23 секунды</p>
        </form>
        <div class="seo-text">
            <h3>МЫ РАБОТАЕМ ДЛЯ ВАС </h3>
            <p>Ничто не сэкономит Ваше время, деньги и нервы так, как качественно выполненная работа.</p>
        </div>
    </div>
</div>
<!-- Этапы укладки -->
<div class="etapi block" id="one">
    <h2>этапы укладки полусухой стяжки пола</h2>
    <div class="etapi-wrap">
        <div class="etapi-l">
            <img src="img/e1.jpg">
            <h3>подготовка основания</h3>
            <p>Во избежание протечек на пол укладывается специальная пленка</p>
        </div>
        <div class="etapi-l">
            <img src="img/e2.jpg">
            <h3>доставка раствора</h3>
            <p>При помощи пневмонагнетателя раствор доставляется на объект (до 70 м. по вертикали и 200м. по горизонтали)</p>
        </div>
        <div class="etapi-l">
            <img src="img/e3.jpg">
            <h3>выставление маяков</h3>
            <p>Маяки выставляются при использовании уровня и лазерного нивелира</p>
        </div>
        <div class="etapi-l">
            <img src="img/e4.jpg">
            <h3>выравнивание стяжки</h3>
            <p>Стяжка тщательно выравнивается мастером по  всему периметру помещения</p>
        </div>
        <div class="etapi-l">
            <img src="img/e5.jpg">
            <h3>финишная затирка</h3>
            <p>При помощи затирочной машины пол приводится к идеально ровному состоянию</p>
        </div>
        <div class="clear"></div>
    </div>
</div>
<!-- Кнопка с чеком -->
<div class="chek block" id="twoo">
    <div class="chek-wrap">
        <h2>НАШИ ЦЕНЫ НА ПОЛУСУХУЮ <br>СТЯЖКУ ПОЛА ПО НЕМЕЦКОЙ <br>ТЕХНОЛОГИИ</h2>
        <p>* Цена указана с учетом высококачественных <br>материалов и работы</p>

        <div class="price-wrap">
                <img src="img/price.png" class="price">
            </div>
        
        <div class="button-wrap">
            <div class="button zamer" onclick="yaCounter39798675.reachGoal('zakaz'); ga('send', 'event','kons','zakaz')">ЗАКАЗАТЬ БЕСПЛАТНЫЙ РАСЧЕТ</div>
        </div>
    </div>
</div>
<!-- Причины -->
<div class="prichini block">
    <h2>РЕАЛЬНЫЕ ПРЕИМУЩЕСТВА, КОТОРЫЕ УЖЕ СДЕЛАЛИ <br>НАС ИСПОЛНИТЕЛЕМ ДЛЯ 1437 ЗАКАЗЧИКОВ</h2>
    <div class="prichini-wrap clearfix">
        <div class="prichini-l">
            <img src="img/prich-1.png">
            <h3>ВСЕГДА БЕЗУПРЕЧНОЕ КАЧЕСТВО РАБОТЫ</h3>
            <p>Современная техника без шума и пыли доставит строительную смесь даже на высоту птичьего полета, и уже очень скоро качественный раствор станет вековым полотном на поверхности пола или стен Вашего объекта</p>
        </div>
        <div class="prichini-l clearfix">
            <img src="img/prich-2.png">
            <h3>ЗНАНИЯ + ОПЫТ = ПРОФЕССИОНАЛИЗМ</h3>
            <p>«Фрактал Строй» – это 10 бригад, с опытом работы свыше 5 лет. Наши мастера регулярно проходят обучение новым технологиям стяжки с использованием инновационных смесей.</p>
        </div>
        <div class="prichini-l clearfix">
            <img src="img/prich-3.png">
            <h3>БЕРЕЖЕМ ВРЕМЯ И ДЕНЬГИ КЛИЕНТАЫ</h3>
            <p>«Фрактал Строй» – идеальные сроки исполнения. Полусухая стяжка не требует от клиента личного контроля над работами, а современное оборудование по - настоящему сократит все расходы.</p>
        </div>

        <div class="prichini-l clearfix">
            <img src="img/prich-4.png">
            <h3>КЛИЕНТ НЕ ТРАТИТСЯ НА МАТЕРИАЛ</h3>
            <p>Стоимость наших услуг – это совокупная стоимость работы и материала, и больше никаких комиссий и скрытых платежей!</p>
        </div>
        <div class="prichini-l clearfix">
            <img src="img/prich-5.png">
            <h3>БОЛЬШОЙ ОБЪЕМ – БОЛЬШАЯ СКИДКА</h3>
            <p>С нами выгодно – <b>ВСЕГДА</b>, но <b>МАСШТАБНЫЕ ПРОЕКТЫ</b> от 1000 м2 и выше, мы выполняем <b>НА ПРИВЛЕКАТЕЛЬНЫХ УСЛОВИЯХ!</b></p>
        </div>
        <div class="prichini-l clearfix">
            <img src="img/prich-6.png">
            <h3>ГАРАНТИЯ 5 ЛЕТ</h3>
            <p>Каждый клиент «Фрактал Строй» получает гарантийный талон сроком 5 лет – и это действует даже при минимальных заказах!</p>
        </div>

    </div>
</div>
<!-- 3 Шага -->
<div class="steps block">
    <h2>3 шага от звонка до идеального пола</h2>
    <div class="steps-wrap">
        <div class="step-l">
            <h3>01</h3>
            <p><span class="zvonok">Оставьте заявку</span> на сайте или по телефону и получите предварительный расчет стоимости.</p>
        </div>
        <div class="step-l">
            <h3>02</h3>
            <p>Мы делаем замер сметы и называем окончательную стоимость без скрытых платежей. Далее подписываем договор и приступаем к работе.</p>
        </div>
        <div class="step-l">
            <h3>03</h3>
            <p>Получите идеальный ровный пол и остаетесь довольны. При этом получаете гарантированный талон на 5 лет.</p>
        </div>
        <div class="clear"></div>
    </div>
</div>
<!-- Отзывы -->
<div class="otzivi block" id="three">
    <h2>отзывы и результаты нашей работы</h2>
    <div class="otzivi-wrap">
        <div class="otzivi-l">
            <div class="inner">
                <p><b>Александр,</b> г. Подольск, площадь 100 м2, средняя толщина 85 мм.</p>
                <div class="galery">
                    <a href="rew/1-1.jpg" data-rel="lightcase:myCollection1" class="gal-img">
                        <img src="rew/1-1.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/1-2.jpg" data-rel="lightcase:myCollection1" class="gal-img">
                        <img src="rew/1-2.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/1-3.jpg" data-rel="lightcase:myCollection1" class="gal-img">
                        <img src="rew/1-3.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/1-4.jpg" data-rel="lightcase:myCollection1" class="gal-img">
                        <img src="rew/1-4.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="inner">
                <a href="rew/1-1.mp4" data-rel="lightcase:myCollection1" class="video">
                    <img src="rew/1-5.jpg" class="video">
                    <img src="img/play.png" class="play">
                </a>
            </div>
            <div class="clear"></div>
        </div>

        <div class="otzivi-l">
            <div class="inner">
                <p><b>Дмитрий,</b> г. Щелково. Площадь 38 м2, средняя толщина 73 мм.</p>
                <div class="galery">
                    <a href="rew/2-1.jpg" data-rel="lightcase:myCollection2" class="gal-img">
                        <img src="rew/2-1.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/2-2.jpg" data-rel="lightcase:myCollection2" class="gal-img">
                        <img src="rew/2-2.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/2-3.jpg" data-rel="lightcase:myCollection2" class="gal-img">
                        <img src="rew/2-3.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/2-4.jpg" data-rel="lightcase:myCollection2" class="gal-img">
                        <img src="rew/2-4.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="inner">
                <a href="rew/2-1.mp4" data-rel="lightcase:myCollection2" class="video">
                    <img src="rew/2-5.jpg" class="video">
                    <img src="img/play.png" class="play">
                </a>
            </div>
            <div class="clear"></div>
        </div>

        <div class="otzivi-l">
            <div class="inner">
                <p><b>Татьяна,</b> г. Москва, ул. Молостовых, площадь 13,5 м2, средняя толщина 60 мм.</p>
                <div class="galery">
                    <a href="rew/3-1.jpg" data-rel="lightcase:myCollection3" class="gal-img">
                        <img src="rew/3-1.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/3-2.jpg" data-rel="lightcase:myCollection3" class="gal-img">
                        <img src="rew/3-2.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/3-3.jpg" data-rel="lightcase:myCollection3" class="gal-img">
                        <img src="rew/3-3.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/3-4.jpg" data-rel="lightcase:myCollection3" class="gal-img">
                        <img src="rew/3-4.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="inner">
                <a href="rew/3-1.mp4" data-rel="lightcase:myCollection3" class="video">
                    <img src="rew/3-5.jpg" class="video">
                    <img src="img/play.png" class="play">
                </a>
            </div>
            <div class="clear"></div>
        </div>

        <div class="otzivi-l">
            <div class="inner">
                <p><b>Константин,</b> г. Москва, ул. Дакутина, 10,  Площадь 240 м2, средняя толщина 90 мм.</p>
                <div class="galery">
                    <a href="rew/4-1.jpg" data-rel="lightcase:myCollection4" class="gal-img">
                        <img src="rew/4-1.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/4-2.jpg" data-rel="lightcase:myCollection4" class="gal-img">
                        <img src="rew/4-2.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/4-3.jpg" data-rel="lightcase:myCollection4" class="gal-img">
                        <img src="rew/4-3.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <a href="rew/4-4.jpg" data-rel="lightcase:myCollection4" class="gal-img">
                        <img src="rew/4-4.jpg">
                        <img src="img/lupe.png" class="hidden">
                    </a>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="inner">
                <a href="rew/4-1.mp4" data-rel="lightcase:myCollection4" class="video">
                    <img src="rew/4-5.jpg" class="video">
                    <img src="img/play.png" class="play">
                </a>
            </div>
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
    </div>
</div>
<!-- Форма справа -->
<div class="form-right-bg">
    <div class="form-right-wrap block">
        <form  method="post" action="/mail.php" class="form-right form">
            <h3>ЗАКАЖИТЕ БЕСПЛАТНЫЙ ЗАМЕР СМЕТЫ СЕЙЧАС</h3>
            <p>И вы сэкономите до 10% за счет наших эксклюзивных скидок у 14 ведущих производителей материалов</p>
            <div class="formphone-wrap">
                <input type="text" name="phone" placeholder="Введите Ваш телефон" value="" tabindex="3" class="formphone">
            </div>
            <div class="button send_mail" tabindex="4" onclick="yaCounter39798675.reachGoal('zakaz'); ga('send', 'event','kons','zakaz')">ЗАКАЗАТЬ ЗАМЕР СМЕТЫ</div>
            <p class="button-desc">* Перезвоним Вам за 23 секунды</p>
        </form>
        <div class="seo-text-r">
            <h3>ДОВЕРЬТЕ РАБОТУ ПРОФИ</h3>
            <p>С нами на всех уровнях работают исключительно профессионалы, и поэтому мы можем обеспечить лучший сервис из имеющихся на рынке.</p>
        </div>
    </div>
</div>
<!-- Контакты -->
<div class="maps-wrap" id="five">


        <div class="contacts-block">
            <div class="cont-wrap">
                <p><span>НАШ АДРЕС</span> <br>г. Москва, Щелковскове шоссе, д.100, оф.135.</p>
                <p><span>НАШ ТЕЛЕФОН</span> <br><a  href="tel:+79684502828" class="roistat-phone ">+7 (968) 450 - 28 - 28</a></p>
                <p><span>НАШ E-MAIL</span> <br><a href="mailto:info@fraktal.ru">info@fraktal.ru</a></p>
                <p><span>ГРАФИК РАБОТЫ</span> <br>Понедельник — суббота с 9:00 до 18:00</p>
            </div>
        </div>

    <div class="map" id="map"></div>
    <div class="clear"></div>
</div>
<!-- Подвал -->
<div class="footer-wrap">
    <div class="footer block">
        <div class="footer-l">
            <p class="foot">© Фрактал Строй 2016</p>
            <a href="http://xn----7sba1bchwkfjher.xn--p1ai/_.pdf" target="_blank">Соглашение об обработке персональных данных</a>
        </div>
        <div class="footer-r">
            <p class="foot">Остались вопросы?</p>
            <a class="vopros">Задайте вопрос прямо сейчас</a>
        </div>
        <div class="clear"></div>
    </div>
</div>


<!-- Модальное окно - Звонок -->

<div style="display: none;">
    <div class="box-modal modal-m" id="exampleModal4">
        <div class="box-modal_close arcticmodal-close"></div>
        <form method="post" action="" class="form">
            <h3>ОСТАВЬТЕ ЗАЯВКУ НА БЕСПЛАТНУЮ КОНСУЛЬТАЦИЮ</h3>
            <p>С нашим специалистом прямо сейчас и он перезвонит Вам за 23 секунды</p>
            <div class="formphone-wrap">
                <input type="text" name="phone" placeholder="Введите Ваш телефон" value="" tabindex="3" class="formphone">
            </div>
            <input type="hidden" name="tarif" value="Start" class="tarif">
            <div class="button send_mail" tabindex="4" onclick="yaCounter39798675.reachGoal('zakaz'); ga('send', 'event','kons','zakaz')">ПОЛУЧИТЬ КОНСУЛЬТАЦИЮ</div>
        </form>
    </div>
</div>

<!-- Модальное окно - Замер -->

<div style="display: none;">
    <div class="box-modal modal-m" id="exampleModal5">
        <div class="box-modal_close arcticmodal-close"></div>
        <form method="post" action="" class="form">
            <h3>ОСТАВЬТЕ ЗАЯВКУ НА БЕСПЛАТНЫЙ РАСЧЕТ СМЕТЫ ПРЯМО СЕЙЧАС</h3>
            <p>И наш специалист перезвонит Вам за 23 секунды</p>
            <div class="formphone-wrap">
                <input type="text" name="phone" placeholder="Введите Ваш телефон" value="" tabindex="3" class="formphone">
            </div>
            <input type="hidden" name="tarif" value="Start" class="tarif">
            <div class="button send_mail" tabindex="4" onclick="yaCounter39798675.reachGoal('zakaz'); ga('send', 'event','kons','zakaz')">Заказать замер</div>
        </form>
    </div>
</div>

<!-- Модальное окно - Вопрос -->
<div style="display: none;">
    <div class="box-modal modal-m" id="exampleModal6">
        <div class="box-modal_close arcticmodal-close"></div>
        <form method="post" action="" class="form">
            <div class="vop-l">
                <h3>ПОЛУЧИТЬ КОНСУЛЬТАЦИЮ </h3>
                <p>Он перезвонит Вам за 23 секунды и ответит более подробно на все вопросы</p>
            </div>
            <div class="vop-l">
                <textarea cols='55' name="vopros" rows='5' placeholder="Введите Ваш вопрос" class="formvopros"></textarea>
                <div class="formphone-wrap">
                    <input type="text" name="phone" placeholder="Введите Ваш телефон" value="" tabindex="3" class="formphone">
                </div>
                <input type="hidden" name="tarif" value="Start" class="tarif">
            </div>
            <div class="clear"></div>
            <div class="button-wrap">
                <div class="button send_mail" tabindex="3" onclick="yaCounter39798675.reachGoal('zakaz'); ga('send', 'event','kons','zakaz')">Заказать замер</div>
            </div>
        </form>
    </div>
</div>
<!-- Модальное окно - Спасибо -->

<div style="display: none;">
    <div class="box-modal mail" id="thx">
        <div class="box-modal_close arcticmodal-close">закрыть</div>
        <h3>Спасибо! <br />
            В ближайшее время <br />
            мы с вами свяжемся!</h3>
    </div>
</div>

<script>
(function(w, d, s, h, id) {
    w.roistatProjectId = id; w.roistatHost = h;
    var p = d.location.protocol == "https:" ? "https://" : "http://";
    var u = /^.*roistat_visit=[^;]+(.*)?$/.test(d.cookie) ? "/dist/module.js" : "/api/site/1.0/"+id+"/init";
    var js = d.createElement(s); js.async = 1; js.src = p+h+u; var js2 = d.getElementsByTagName(s)[0]; js2.parentNode.insertBefore(js, js2);
})(window, document, 'script', 'cloud.roistat.com', '31fa67bf522692caf60630b2137b5e44');
</script>

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter39798675 = new Ya.Metrika({
                    id:39798675,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    webvisor:true,
                    trackHash:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/39798675" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->


<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-84768954-1', 'auto');
  ga('send', 'pageview');

</script>


<!-- Google Code for &#1050;&#1085;&#1086;&#1087;&#1082;&#1072; &#1079;&#1072;&#1082;&#1072;&#1079; Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 951046342;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "0PPBCL65ymoQxqG_xQM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/951046342/?label=0PPBCL65ymoQxqG_xQM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>



</body>
</html>