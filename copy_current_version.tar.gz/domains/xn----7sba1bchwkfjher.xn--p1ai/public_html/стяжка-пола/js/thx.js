$(function() {

   /*$(window).load(function () {
       var head = $('.wrapper');
        var headH = $(head).height();
        var wH = $(window).height();

       if (wH > 700) {
           $(head).height(wH);
       }
       else {
           $(head).css('height', 'auto');
       }
    });

    $(window).resize(function () {
        var head = $('.wrapper');
        var headH = $(head).height();
        var wH = $(window).height();

        if (wH > 700) {
            $(head).height(wH);
        }
        else {
            $(head).css('height', 'auto');
        }
    });*/

    


    


});
